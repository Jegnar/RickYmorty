export interface Personaje{
    nombre: string;
    imagen: string;
    estado: string;
}